import React from "react";

export default function CTA() {
  return (
    <section className="bg-[#C0B8AF] py-16">
      <div className="max-w-[1200px] mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold text-[#1E1C25] mb-4">
          Ready to Begin Your Sacred Journey?
        </h2>
        <p className="text-[#637F95] text-lg mb-8 max-w-2xl mx-auto">
          Discover authentic religious items, spiritual guides, and convenient scrap buyback services. 
          Everything you need for your spiritual practice, delivered with devotion.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-[#C28142] hover:bg-[#94331F] text-white px-8 py-3 rounded-[8px] font-medium transition-colors shadow-[0_6px_18px_rgba(30,28,37,0.08)]">
            Shop Now
          </button>
          <button className="border-2 border-[#94331F] text-[#94331F] hover:bg-[#94331F] hover:text-white px-8 py-3 rounded-[8px] font-medium transition-colors">
            Learn More
          </button>
        </div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-[#C28142] mb-2">1000+</div>
            <p className="text-[#637F95]">Happy Customers</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-[#C28142] mb-2">500+</div>
            <p className="text-[#637F95]">Products Available</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-[#C28142] mb-2">24/7</div>
            <p className="text-[#637F95]">Customer Support</p>
          </div>
        </div>
      </div>
    </section>
  );
}
